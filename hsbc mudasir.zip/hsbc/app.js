import OAuth from 'oauth-1.0a';
import axios from 'axios';
import CryptoJS from 'crypto-js';
import express from 'express';
import dotenv from 'dotenv';
dotenv.config();

const app = express();
// let netsuiteData;

app.get('/nsdata', async (req, res) => {
  //get id from query object
  // console.log(req.query.fileId)
  var nsfileId = req.query.fileId;

  // tokens
  const CONSUMER_KEY = '9594d0444faa3e172d3d6bf8de90d71d842c0a4683acc14c8e26b39eed9ffeb9'
  const CONSUMER_SECRET = '8ea73bfb35030b00d22792f4ac6d926476dd4327211d394fe097afcad3255918'
  const ACCESS_TOKEN = 'aa155d7855e71e274bb248a97364bc8e9d251a80b72d9eb837cf32a33bfc5569'
  const ACCESS_TOKEN_SECRET = '43e5766171c6b6380ad0bcb515d495397ee1b5450b74fd5e1d95f890b9d5ba8b'
  const REALM = "5033870_SB1"
  const url = 'https://5033870-sb1.restlets.api.netsuite.com/app/site/hosting/restlet.nl?script=1921&deploy=1&fileId='+nsfileId;

  //oauth header
  const oauth = OAuth({
    consumer: {
      key: CONSUMER_KEY,
      secret: CONSUMER_SECRET,
    },
    signature_method: 'HMAC-SHA256',
    hash_function(base_string, key) {
      const signature = CryptoJS.HmacSHA256(base_string, key);
      return CryptoJS.enc.Base64.stringify(signature);
    },
  });

  const token = {
    key: ACCESS_TOKEN,
    secret: ACCESS_TOKEN_SECRET,
  };

  const requestData = {
    url,
    method: 'GET',
  };

  const headers = oauth.toHeader(oauth.authorize(requestData, token));

  // Add realm parameter to the OAuth header
  headers['Authorization'] += `,realm="${REALM}"`;
  await axios({
    url,
    method: 'GET',
    headers,
  }).then((response) => {
      // console.log(response.data);
      res.json(response.data);
    })
    .catch((error) => {
      console.error(error);
      res.send(error);
    });
});

app.listen(5000, () => {
  console.log('Server started on port 5000');
});
